# 26-Oct-2026 — Employee & Department Microservices: DB Integration

## Database setup (MySQL Workbench)
```sql
CREATE DATABASE employee_department_db;
USE employee_department_db;
```

Set your own MySQL username/password in environment variables `DB_USERNAME` and `DB_PASSWORD`, or locally in `application.properties`. Do not upload credentials to GitHub.

## Postman tests
Base URL: `http://localhost:8080`

### 1. Create department
POST `/api/departments`, Body > raw > JSON:
```json
{"name":"IT","location":"Hyderabad"}
```
Expected: `201 Created`, with a generated department ID.

### 2. Create employee
POST `/api/employees`, Body > raw > JSON:
```json
{"name":"Ravi Kumar","email":"ravi@example.com","salary":35000,"department":{"id":1}}
```
Expected: `201 Created`, with a generated employee ID and department ID 1.

### 3. Read data
GET `/api/departments` and GET `/api/employees`
Expected: `200 OK` and JSON arrays.

### 4. Verify persistence in Workbench
```sql
USE employee_department_db;
SELECT * FROM departments;
SELECT * FROM employees;
```
Inserted records should be visible. Restart the app and run the SELECT statements again to confirm persistence.

### 5. Additional CRUD and error tests
- PUT `/api/employees/1` — expected `200 OK` after a valid update.
- DELETE `/api/employees/1` — expected `204 No Content`.
- Empty employee name — expected `400 Bad Request`.
- GET `/api/employees/999999` — expected `404 Not Found`.

Note: These are expected results, not evidence that the application has actually been run. Execute the tests before marking them complete. This starter has two controllers in one Spring Boot app; it is not two independently deployed microservices.
