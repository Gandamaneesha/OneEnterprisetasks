package com.example.employeedepartment.mapper;

import com.example.employeedepartment.dto.EmployeeResponseDTO;
import com.example.employeedepartment.entity.Employee;

public class EmployeeMapper {
    public static EmployeeResponseDTO toResponse(Employee employee) {
        EmployeeResponseDTO dto = new EmployeeResponseDTO();
        dto.setId(employee.getId());
        dto.setName(employee.getName());
        dto.setEmail(employee.getEmail());
        dto.setSalary(employee.getSalary());

        if (employee.getDepartment() != null) {
            dto.setDepartmentId(employee.getDepartment().getId());
            dto.setDepartmentName(employee.getDepartment().getName());
        }
        return dto;
    }
}
