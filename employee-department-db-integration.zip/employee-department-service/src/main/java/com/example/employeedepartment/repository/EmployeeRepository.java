package com.example.employeedepartment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.employeedepartment.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {}
