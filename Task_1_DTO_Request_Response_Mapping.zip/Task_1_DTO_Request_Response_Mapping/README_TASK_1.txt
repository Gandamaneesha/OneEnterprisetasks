TASK 1 - DTOs and Request/Response Mapping

Add these files to the existing Employee & Department project:
dto/EmployeeRequestDTO.java
dto/EmployeeResponseDTO.java
dto/DepartmentRequestDTO.java
dto/DepartmentResponseDTO.java
mapper/EmployeeMapper.java
mapper/DepartmentMapper.java

The output folder contains expected Postman requests/responses.

Note: the mapper classes depend on the existing Employee and Department entities.
The existing controller/service code must be connected to these DTOs for the complete integrated Task 1 implementation.
