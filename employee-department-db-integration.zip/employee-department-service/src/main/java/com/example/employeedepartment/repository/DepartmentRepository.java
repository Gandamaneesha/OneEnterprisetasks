package com.example.employeedepartment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.employeedepartment.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {}
