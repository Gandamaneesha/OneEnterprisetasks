package com.example.employeedepartment.dto;

public class DepartmentRequestDTO {
    private String name;
    private String location;

    public DepartmentRequestDTO() {}

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
}
