package com.example.employeedepartment.mapper;

import com.example.employeedepartment.dto.DepartmentResponseDTO;
import com.example.employeedepartment.entity.Department;

public class DepartmentMapper {
    public static DepartmentResponseDTO toResponse(Department department) {
        DepartmentResponseDTO dto = new DepartmentResponseDTO();
        dto.setId(department.getId());
        dto.setName(department.getName());
        dto.setLocation(department.getLocation());
        return dto;
    }
}
