package com.example.employeedepartment.controller;

import java.util.List;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.example.employeedepartment.entity.Employee;
import com.example.employeedepartment.entity.Department;
import com.example.employeedepartment.repository.EmployeeRepository;
import com.example.employeedepartment.repository.DepartmentRepository;
import com.example.employeedepartment.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;

    public EmployeeController(EmployeeRepository employeeRepository,
                              DepartmentRepository departmentRepository) {
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Employee create(@Valid @RequestBody Employee employee) {
        attachDepartmentIfProvided(employee);
        return employeeRepository.save(employee);
    }

    @GetMapping
    public List<Employee> getAll() {
        return employeeRepository.findAll();
    }

    @GetMapping("/{id}")
    public Employee getById(@PathVariable Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + id));
    }

    @PutMapping("/{id}")
    public Employee update(@PathVariable Long id, @Valid @RequestBody Employee input) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + id));
        employee.setName(input.getName());
        employee.setEmail(input.getEmail());
        employee.setSalary(input.getSalary());
        attachDepartmentIfProvided(input);
        employee.setDepartment(input.getDepartment());
        return employeeRepository.save(employee);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + id));
        employeeRepository.delete(employee);
    }

    private void attachDepartmentIfProvided(Employee employee) {
        if (employee.getDepartment() != null && employee.getDepartment().getId() != null) {
            Long departmentId = employee.getDepartment().getId();
            Department department = departmentRepository.findById(departmentId)
                    .orElseThrow(() -> new ResourceNotFoundException("Department not found: " + departmentId));
            employee.setDepartment(department);
        } else {
            employee.setDepartment(null);
        }
    }
}
