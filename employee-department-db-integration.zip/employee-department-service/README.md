# Employee & Department REST API

A Java 17 / Spring Boot project demonstrating employee and department CRUD REST endpoints, Spring Data JPA, H2 database, request validation, and exception handling.

> Note: This starter project runs both resource controllers in one Spring Boot application. If your trainer requires separately deployable microservices, split Employee and Department into separate applications and add service-to-service communication.

## Requirements
- JDK 17+
- Spring Tool Suite (STS) or another Java IDE
- Maven (STS can use the included Maven configuration)
- Postman (for API tests)

## Run in STS
1. Import as **Existing Maven Project** (File > Import > Maven > Existing Maven Projects).
2. Select the folder containing `pom.xml`.
3. Right-click the project > Maven > Update Project.
4. Run `EmployeeDepartmentApplication.java` as **Spring Boot App**.
5. Check the Console for a successful start on port 8080.

## Endpoints

| Method | URL | Purpose |
|---|---|---|
| POST | `/api/departments` | Create department |
| GET | `/api/departments` | List departments |
| GET | `/api/departments/{id}` | Get one department |
| PUT | `/api/departments/{id}` | Update department |
| DELETE | `/api/departments/{id}` | Delete department |
| POST | `/api/employees` | Create employee |
| GET | `/api/employees` | List employees |
| GET | `/api/employees/{id}` | Get one employee |
| PUT | `/api/employees/{id}` | Update employee |
| DELETE | `/api/employees/{id}` | Delete employee |

## Sample requests

Create department (`POST http://localhost:8080/api/departments`):
```json
{"name":"IT","location":"Hyderabad"}
```

Create employee (`POST http://localhost:8080/api/employees`):
```json
{
  "name":"Ravi Kumar",
  "email":"ravi@example.com",
  "salary":35000,
  "department":{"id":1}
}
```

## H2 Console
Open `http://localhost:8080/h2-console` while the app is running.
- JDBC URL: `jdbc:h2:mem:employeedb`
- Username: `sa`
- Password: (leave blank)

SQL:
```sql
SELECT * FROM DEPARTMENTS;
SELECT * FROM EMPLOYEES;
```

H2 is an in-memory database; records are cleared when the application stops.

## Expected response codes
- `201 Created` for successful POST requests
- `200 OK` for successful GET/PUT requests
- `204 No Content` for successful DELETE requests
- `400 Bad Request` for validation errors
- `404 Not Found` for missing employee/department IDs
- `409 Conflict` for a duplicate unique email or another database constraint conflict


## MySQL DB integration (26-Oct task)
1. Start MySQL Server and open MySQL Workbench.
2. Execute `CREATE DATABASE employee_department_db;`.
3. Configure `DB_USERNAME` and `DB_PASSWORD` environment variables, or set your local credentials in `application.properties`. Do not commit passwords to GitHub.
4. Run the Spring Boot app. Hibernate creates/updates the `employees` and `departments` tables.
5. Create records through Postman, then verify with:
```sql
USE employee_department_db;
SELECT * FROM departments;
SELECT * FROM employees;
```
MySQL records persist after restarting the application.
